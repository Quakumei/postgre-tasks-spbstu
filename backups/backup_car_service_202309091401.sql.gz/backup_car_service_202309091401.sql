--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8
-- Dumped by pg_dump version 15.4 (Ubuntu 15.4-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: tampio
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO tampio;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cars; Type: TABLE; Schema: public; Owner: tampio
--

CREATE TABLE public.cars (
    id integer NOT NULL,
    num character varying(20) NOT NULL,
    color character varying(20),
    mark character varying(20),
    is_foreign boolean
);


ALTER TABLE public.cars OWNER TO tampio;

--
-- Name: cars_id_seq; Type: SEQUENCE; Schema: public; Owner: tampio
--

CREATE SEQUENCE public.cars_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cars_id_seq OWNER TO tampio;

--
-- Name: cars_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tampio
--

ALTER SEQUENCE public.cars_id_seq OWNED BY public.cars.id;


--
-- Name: masters; Type: TABLE; Schema: public; Owner: tampio
--

CREATE TABLE public.masters (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.masters OWNER TO tampio;

--
-- Name: masters_id_seq; Type: SEQUENCE; Schema: public; Owner: tampio
--

CREATE SEQUENCE public.masters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.masters_id_seq OWNER TO tampio;

--
-- Name: masters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tampio
--

ALTER SEQUENCE public.masters_id_seq OWNED BY public.masters.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: tampio
--

CREATE TABLE public.services (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    cost_our numeric(18,2),
    cost_foreign numeric(18,2)
);


ALTER TABLE public.services OWNER TO tampio;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: tampio
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_id_seq OWNER TO tampio;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tampio
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: works; Type: TABLE; Schema: public; Owner: tampio
--

CREATE TABLE public.works (
    id integer NOT NULL,
    date_work date,
    master_id integer,
    car_id integer,
    service_id integer
);


ALTER TABLE public.works OWNER TO tampio;

--
-- Name: works_id_seq; Type: SEQUENCE; Schema: public; Owner: tampio
--

CREATE SEQUENCE public.works_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.works_id_seq OWNER TO tampio;

--
-- Name: works_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tampio
--

ALTER SEQUENCE public.works_id_seq OWNED BY public.works.id;


--
-- Name: cars id; Type: DEFAULT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.cars ALTER COLUMN id SET DEFAULT nextval('public.cars_id_seq'::regclass);


--
-- Name: masters id; Type: DEFAULT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.masters ALTER COLUMN id SET DEFAULT nextval('public.masters_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: works id; Type: DEFAULT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.works ALTER COLUMN id SET DEFAULT nextval('public.works_id_seq'::regclass);


--
-- Data for Name: cars; Type: TABLE DATA; Schema: public; Owner: tampio
--

COPY public.cars (id, num, color, mark, is_foreign) FROM stdin;
1	а905ав777	Красный	Honda	t
2	б123ка717	Белый	Лада	f
3	б128кф939	Чёрный	Лада	f
4	а888щл913	Фиолетовый	Mazda	t
5	г123ар834	Бирюзовый	УАЗ	f
\.


--
-- Data for Name: masters; Type: TABLE DATA; Schema: public; Owner: tampio
--

COPY public.masters (id, name) FROM stdin;
1	Василий
2	Сергей
3	Юлиана
4	Анатолий
5	Пётр
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: tampio
--

COPY public.services (id, name, cost_our, cost_foreign) FROM stdin;
1	Мытьё машины	500.00	1500.00
2	Замена карбюратора	5000.00	7500.00
3	Смена резины	2500.00	4000.00
\.


--
-- Data for Name: works; Type: TABLE DATA; Schema: public; Owner: tampio
--

COPY public.works (id, date_work, master_id, car_id, service_id) FROM stdin;
1	2023-01-25	1	1	1
2	2023-01-26	2	2	2
3	2023-01-27	3	3	3
4	2023-01-27	1	3	2
\.


--
-- Name: cars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tampio
--

SELECT pg_catalog.setval('public.cars_id_seq', 5, true);


--
-- Name: masters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tampio
--

SELECT pg_catalog.setval('public.masters_id_seq', 5, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tampio
--

SELECT pg_catalog.setval('public.services_id_seq', 3, true);


--
-- Name: works_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tampio
--

SELECT pg_catalog.setval('public.works_id_seq', 4, true);


--
-- Name: cars cars_pkey; Type: CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_pkey PRIMARY KEY (id);


--
-- Name: masters masters_pkey; Type: CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.masters
    ADD CONSTRAINT masters_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: works works_pkey; Type: CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_pkey PRIMARY KEY (id);


--
-- Name: works fk_works_cars; Type: FK CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_works_cars FOREIGN KEY (car_id) REFERENCES public.cars(id);


--
-- Name: works fk_works_masters; Type: FK CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_works_masters FOREIGN KEY (master_id) REFERENCES public.masters(id);


--
-- Name: works fk_works_services; Type: FK CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_works_services FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: works works_car_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_car_id_fkey FOREIGN KEY (car_id) REFERENCES public.cars(id);


--
-- Name: works works_master_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_master_id_fkey FOREIGN KEY (master_id) REFERENCES public.masters(id);


--
-- Name: works works_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tampio
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: tampio
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

